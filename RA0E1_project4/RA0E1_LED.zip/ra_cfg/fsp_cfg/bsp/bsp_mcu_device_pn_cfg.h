/* generated configuration header file - do not edit */
#ifndef BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_R7FA0E1073CFJ
#define BSP_MCU_FEATURE_SET ('0')
#define BSP_ROM_SIZE_BYTES (65536)
#define BSP_RAM_SIZE_BYTES (12288)
#define BSP_DATA_FLASH_SIZE_BYTES (1024)
#define BSP_PACKAGE_LQFP
#define BSP_PACKAGE_PINS (32)
#endif /* BSP_MCU_DEVICE_PN_CFG_H_ */
